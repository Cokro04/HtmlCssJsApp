// ApiKey
let apiKey = 'b9847524c23b3e3b3df529d0269077ff';

function callWeatherApi(city){
    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`)
    .then((response) => {
        return response.json()
    }).then((data) => {
        console.log(data);
        showWeatherApi(data);
    }).catch((error) => {
        Swal.fire({
            icon: 'error',
            title: '0ops...',
            text: 'Something went wrong! Please Try again',
        })
        console.log(error);
    })
}

callWeatherApi('jakarta');

// menampilkan data dariAPI

const leftSide = document.querySelector(".left-side");

function showWeatherApi(data){
    if(data){
        const {name} = data;
        const {description, icon} = data.weather[0];
        const {humidity, temp} = data.main;
        const {speed} = data.wind;

        leftSide.innerHTML = `
        <h1>weather in ${name}</h1>
        <div class="temp">
            <i class="bx bxs-thermometer"></i>
            ${temp}°C
        </div>
        <div class="icon-desc">
            <img src="https://openweathermap.org/img/wn/${icon}.png" alt="">
            <div>${description}</div>
        </div>
        <div>
            <i class="bx bx-droplet"></i>
            humiddity: ${humidity} %
        </div>
        <div>
            <i class="bx bx-wind"></i>
            wind speed: ${speed} km/h
        </div>`
    }
}

// cari kota
const searchButton = document.querySelector(".search-box button");
const searchInput = document.querySelector(".search-box input");

searchButton.addEventListener('click', () => {
    let inputValue = searchInput.value;
    if (inputValue) {
        callWeatherApi(inputValue)
    } else {
        Swal.fire({
            icon: 'info',
            title: 'City Name !?',
            text: 'please enter the city name',
        })
    }
})

searchInput.addEventListener('keyup', (e) => {
    let inputValue = searchInput.value;
    if(inputValue) {
        e.key == 'Enter' && callWeatherApi(inputValue)
    } else if(!inputValue && e.key == 'Enter') {
        Swal.fire({
            icon: 'info',
            title: 'City Name !?',
            text: 'please enter the city name',
        })
    }
})


